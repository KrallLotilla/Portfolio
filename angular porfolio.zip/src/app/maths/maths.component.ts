import { Component } from '@angular/core';

@Component({
  selector: 'app-maths',
  templateUrl: './maths.component.html',
  styleUrl: './maths.component.scss'
})
export class MathsComponent {

}
