import { Component } from '@angular/core';

@Component({
  selector: 'app-chess',
  templateUrl: './chess.component.html',
  styleUrl: './chess.component.scss'
})
export class ChessComponent {

}
